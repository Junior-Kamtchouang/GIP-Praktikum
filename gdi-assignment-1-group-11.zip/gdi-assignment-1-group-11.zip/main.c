#include <stdio.h>

int main()
{
    // Force (F) = m * a
//    mass für Gewicht, forcr für Kraft, acceleration für Beschleunigung
//Strecke für Zurückgelgtestrecke, rime für Zeit
//    work(W) für Arbeit, height für höhe,

//Variablen Deklaration
    float mass,  force, work, height, energie_Pot;
    int strecke, time;
    int  acceleration;

    //3a)

    printf("Welche Masse (kg) hat der Körper?");
    scanf("%f", &mass);

    printf("\nUnd welche Beschleunigung (m/s*s)?");
    scanf("%d", &acceleration);

    force = mass * acceleration;// Formel der Kraft

    printf("\nDie Kraft beträgt %.2f Newton!\n", force);


    //3b)

    printf("\n \nGeben Sie die zurückgelegte Strecke(m) der Körper");
    scanf("%d", &strecke);

    printf("\nWie lange dauert es(s)? ");
    scanf("%d", &time);

    acceleration = strecke /(time*time); //Formel der Beschleunigung

    printf("\n Die Beschleunigung ist: %d\n", acceleration);

    // 3c)

    work = force * strecke; //Formel der Arbeit

    printf("\n \nDie Arbeit entspricht %.3f Newton pro Meter" ,work);


    // 3d)
    //...

    printf("\n \nGeben Sie eine Höhe(m)" );
    scanf("%f", &height);

    energie_Pot = mass * height* 9.81; // Formel der Potenzielle Energie

    printf("\nDie Potenzielle Energie ist: %.3f", energie_Pot);

    return 0;
}